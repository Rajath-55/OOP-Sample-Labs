public class Lab {
	private int labCode;
	private int currentNumberOfStudents;
	private int maxCapacity;
	
	Lab(int labCode, int maxCapacity){
		this.labCode = labCode;
		this.currentNumberOfStudents = 0;
		this.maxCapacity = maxCapacity;
	}
	
	int getLabCode() {
		return labCode;
	}
	
	int getCurrentNumberOfStudents() {
		return currentNumberOfStudents;
	}
	
	int getMaxCapacity() {
		return maxCapacity;
	}
	
	void increaseSeats(int numSeats) {
		maxCapacity += numSeats;
	}
	
	void updateCurrentNumberOfStudents() {
		currentNumberOfStudents++;
	}
}