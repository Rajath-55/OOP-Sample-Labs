public class Lab {


    // Add Class Variables


    Lab(int labCode, int maxCapacity){

        // Add code here

    }


    //Add remaining methods (*5)
    
}
