public class Admin {

    // Add field Variables


    Admin(int maxPerYearCapacity, Lab[] labs){
        // Add code here



    }


    // Add remaining Methods (*5)
    
}
